#ifndef DEBUG
#include "GeneratedBuildInfo.h"
#else // ifdef DEBUG
#define BUILD_HASH "DEBUG"
#define BUILD_DATE "0000-00-00"
#define BUILD_TIME "00:00:00"
#endif // ifdef DEBUG